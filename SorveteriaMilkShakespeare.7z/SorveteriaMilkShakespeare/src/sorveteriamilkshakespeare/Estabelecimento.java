package sorveteriamilkshakespeare;

import state.Preparando;
import state.AndamentoPedido;
import state.Finalizado;

public class Estabelecimento{
    
    AndamentoPedido andamentoPedido;
    
    public void statusPedido(String status, Sorvete Sorvete){
        if(status.equalsIgnoreCase("Preparando . . .")){
            this.andamentoPedido = new Preparando();
            this.andamentoPedido.statusPedido(Sorvete);
        }else if(status.equalsIgnoreCase("Finalizado. Favor retirar no balcão.")){
            this.andamentoPedido = new Finalizado();
            this.andamentoPedido.statusPedido(Sorvete);
        }
        this.andamentoPedido.statusPedido(Sorvete);
    }
    
}

