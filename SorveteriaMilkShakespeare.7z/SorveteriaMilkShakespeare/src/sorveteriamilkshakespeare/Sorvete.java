package sorveteriamilkshakespeare;

public class Sorvete {

    private String Nome = " ";
    private String status = " ";
    private boolean caldaQuente = false;
    private boolean tubeteFini = false ;
    private boolean nutella = false ;
    private boolean leiteNinho = false ;
    private boolean jujuba = false ;
    private boolean disquete = false ;
    private boolean caldaNormal = false ;

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        this.Nome = nome;
    }

    public boolean iscaldaQuente() {
        return caldaQuente;
    }

    public void setcaldaQuente(boolean caldaQuente) {
        this.caldaQuente = caldaQuente;
    }

    public boolean isTubeteFini() {
        return tubeteFini;
    }

    public void setTubeteFini(boolean tubeteFini) {
        this.tubeteFini = tubeteFini;
    }

    public boolean isNutella() {
        return nutella;
    }

    public void setNutella(boolean nutellça) {
        this.nutella = nutella;
    }

    public boolean isleiteNinho() {
        return leiteNinho;
    }

    public void setleiteNinho(boolean leiteNinho) {
        this.leiteNinho = leiteNinho;
    }

    public boolean isjujuba() {
        return jujuba;
    }

    public void setjujuba(boolean jujuba) {
        this.jujuba = jujuba;
    }

    public boolean isdisquete() {
        return disquete;
    }

    public void setdisquete(boolean disquete) {
        this.disquete = disquete;
    }

    public boolean iscaldaNormal() {
        return caldaNormal;
    }

    public void setcaldaNormal(boolean caldaNormal) {
        this.caldaNormal = caldaNormal;
    }

   
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
