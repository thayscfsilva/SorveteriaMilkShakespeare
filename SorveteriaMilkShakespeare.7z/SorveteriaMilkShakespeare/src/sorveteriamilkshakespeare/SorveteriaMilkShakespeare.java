package sorveteriamilkshakespeare;

import factory.SorveteFactory;

public class SorveteriaMilkShakespeare {

    public static void main(String[] args) {
       
        Sorvete sorvete;
        Estabelecimento estabelecimento = new Estabelecimento();
        
        sorvete = new SorveteFactory().buildSorvete("Leite Ninho");
        estabelecimento.statusPedido("Preparando . . .", sorvete);
        
        System.out.println("STATUS: " + sorvete.getStatus());
        
        System.out.println("Aceita calda quente: " + sorvete.iscaldaQuente());
        
        System.out.println("Aceita tubete fini: " + sorvete.isTubeteFini());
        
        System.out.println("Aceita nutella: " + sorvete.isNutella());
        
        System.out.println("Aceita leite ninho: " + sorvete.isleiteNinho());
        
        System.out.println("Aceita jujuba: " + sorvete.isjujuba());
        
        System.out.println("Aceita disquete: " + sorvete.isdisquete());
        
        System.out.println("Aceita calda normal: " + sorvete.iscaldaNormal());
        
    }
    
}
