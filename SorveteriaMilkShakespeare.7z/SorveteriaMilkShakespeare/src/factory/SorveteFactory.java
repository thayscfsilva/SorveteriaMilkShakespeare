package factory;

import builder.SorveteriaBuilder;
import sorveteriamilkshakespeare.Sorvete;

public class SorveteFactory implements FactoryAbstrata{

    @Override
    public Sorvete buildSorvete(String Adicionais) {
        if(Adicionais.equalsIgnoreCase("1 bola")){
            return new SorveteriaBuilder()
                    
                    .caldaQuente(true)
                    .leiteNinho(true)
                    .build();
            
        }else if(Adicionais.equalsIgnoreCase("2 bolas")){
            return new SorveteriaBuilder()
                    
                    .nutella(true)
                    .caldaNormal(true)
                    .jujuba(true)
                    .build();
            
        } else if(Adicionais.equalsIgnoreCase("No quilo")){
            return new SorveteriaBuilder()
                    
                    .caldaQuente(true)
                    .TubeteFini(true)
                    .nutella(true)
                    .leiteNinho(true)
                    .jujuba(true)
                    .build();
            
        }
        
        return new SorveteriaBuilder()
                .isName("Disquete com Nutella")
                .caldaNormal(true)
                .nutella(true)
                .disquete(true)
                .build();
    }

}
