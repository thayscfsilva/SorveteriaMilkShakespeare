
package factory;

import sorveteriamilkshakespeare.Sorvete;

public interface FactoryAbstrata {
     public Sorvete buildSorvete(String Adicionais); 
}
