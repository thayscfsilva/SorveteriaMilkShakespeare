package builder;

import sorveteriamilkshakespeare.Sorvete;

public class SorveteriaBuilder {
    
    private Sorvete sorvete;
    
    public SorveteriaBuilder(){
        this.sorvete = new Sorvete();
    }
    
    public SorveteriaBuilder caldaQuente(boolean caldaQuente) {
	this.sorvete.setcaldaQuente(caldaQuente);
        return this;
    }
    
    public SorveteriaBuilder TubeteFini(boolean tubeteFini){
        this.sorvete.setTubeteFini(tubeteFini);
        return this;
    }
    
    public SorveteriaBuilder nutella(boolean nutella){
        this.sorvete.setNutella(nutella);
        return this;
    }
    
    public SorveteriaBuilder leiteNinho(boolean leiteNinho){
        this.sorvete.setleiteNinho(leiteNinho);
        return this;
    }
    
    public SorveteriaBuilder jujuba(boolean jujuba){
        this.sorvete.setjujuba(jujuba);
        return this;
    }
    
    public SorveteriaBuilder disquete(boolean disquete){
        this.sorvete.setdisquete(disquete);
        return this;
    }
    
    public SorveteriaBuilder caldaNormal(boolean caldaNormal){
        this.sorvete.setcaldaNormal(caldaNormal);
        return this;
    }
    
    public SorveteriaBuilder isName(String nomeSorvete){
        this.sorvete.setNome(nomeSorvete);
        return this;
    }
    
    public Sorvete build(){
        return this.sorvete;
    }
    
}
