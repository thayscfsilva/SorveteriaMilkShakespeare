package state;

import sorveteriamilkshakespeare.Sorvete;

public class Preparando implements AndamentoPedido{

    Sorvete sorvete;
    
    @Override
    public void statusPedido(Sorvete sorvete) {
        this.sorvete = sorvete;
        this.sorvete.setStatus("Estamos preparando seu pedido. Por favor aguarde.");
    }
    
}
