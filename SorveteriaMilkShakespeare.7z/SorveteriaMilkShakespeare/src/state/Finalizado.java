package state;

import sorveteriamilkshakespeare.Sorvete;

public class Finalizado implements AndamentoPedido{

    Sorvete sorvete;
    
    @Override
    public void statusPedido(Sorvete sorvete) {
        this.sorvete = sorvete;
        this.sorvete.setStatus("Pedido finalizado. Favor retirar no balcão.");
    }
    
}
