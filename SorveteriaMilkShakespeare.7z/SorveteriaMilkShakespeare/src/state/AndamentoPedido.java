package state;

import sorveteriamilkshakespeare.Sorvete;

public interface AndamentoPedido {
    public void statusPedido(Sorvete sorvete);
}
